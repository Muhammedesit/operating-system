#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX_CUSTOMERS 27
#define MAX_WAITING_CHAIRS 5

pthread_mutex_t mutex;
pthread_cond_t barber_ready;
pthread_cond_t customer_ready;

int waiting_customers = 0;
int next_customer = 0;
int customers_served = 0;

int num_customers, max_arrival_time, max_haircut_duration, haircut_repetition;

void* customer_thread(void* arg) {
    intptr_t customer_id = (intptr_t) arg;
    int haircuts = 0;
    while (haircuts < haircut_repetition) {
        pthread_mutex_lock(&mutex);
        if (waiting_customers < MAX_WAITING_CHAIRS) {
            waiting_customers++;
            printf("Customer %ld waiting\n", customer_id);
            pthread_cond_signal(&customer_ready);
            pthread_cond_wait(&barber_ready, &mutex);
            waiting_customers--;
            haircuts++;
            customers_served++;
            printf("Customer %ld getting hair cut\n", customer_id);
            pthread_mutex_unlock(&mutex);
            usleep(rand() % (max_haircut_duration*1000));
        } else {
            printf("No more waiting chairs for Customer %ld\n", customer_id);
            pthread_mutex_unlock(&mutex);
        }
        usleep(rand() % (max_arrival_time*1000));
    }
    printf("Customer %ld leaving\n", customer_id);
    pthread_exit(0);
}

void* barber_thread(void* arg) {
    while (customers_served < num_customers * haircut_repetition) {
        pthread_mutex_lock(&mutex);
        if (waiting_customers > 0) {
            next_customer++;
            if (next_customer > MAX_CUSTOMERS) {
                next_customer = 1;
            }
            pthread_cond_signal(&barber_ready);
            printf("Barber cutting hair of customer %d\n", next_customer);
        } else {
            printf("Barber sleeping\n");
            pthread_cond_wait(&customer_ready, &mutex);
        }
        pthread_mutex_unlock(&mutex);
    }
    pthread_exit(0);
}

int main(int argc, char* argv[]) {
    if (argc != 5) {
        printf("Usage: ./a.out <num_customers> <max_arrival_time> <max_haircut_duration> <haircut_repetition>\n");
        return -1;
    }

    num_customers = atoi(argv[1]);
    max_arrival_time = atoi(argv[2]);
    max_haircut_duration = atoi(argv[3]);
    haircut_repetition = atoi(argv[4]);

    pthread_t barber, customers[MAX_CUSTOMERS];

    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&barber_ready, NULL);
    pthread_cond_init(&customer_ready, NULL);

    pthread_create(&barber, NULL, barber_thread, NULL);

    for (int i = 1; i <= num_customers; i++) {
        pthread_create(&customers[i], NULL, customer_thread, (void*) i);
    }

    for (int i = 1; i <= num_customers; i++) {
        pthread_join(customers[i], NULL);
    }

    pthread_join(barber, NULL);

    pthread_cond_destroy(&barber_ready);
    pthread_cond_destroy(&customer_ready);
    pthread_mutex_destroy(&mutex);

    return 0;
}