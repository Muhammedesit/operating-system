make

./hw3test 25 500 100 50
