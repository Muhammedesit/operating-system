#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <linux/mman.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX_LINES 100
#define MAX_LEN 1000



int main() {



  char line[1024] ;
   FILE* fp1 = fopen(file1, "r") ;
    FILE* fp2 = fopen(file2, "r") ;
     FILE* fp3 = fopen(file3, "r") ;
    FILE* fw = fopen("output.txt", "w+") ;
    int i=0;

   while (fgets(line , sizeof(line) , fp1 )!= NULL)
   {
   i++;

      if (strstr(line , word )!= NULL)
      {
          fprintf(fw, "<%s> <%d> %s",file1,i,line);

        }
   }
fprintf(fw,"\n");
      i=0;

   while (fgets(line , sizeof(line) , fp2 )!= NULL)
   {
   i++;

      if (strstr(line , word )!= NULL)
      {
          fprintf(fw, "<%s> <%d> %s",file2,i,line);

       }
   }
fprintf(fw,"\n");
     i=0;

   while (fgets(line , sizeof(line) , fp3 )!= NULL)
   {
   i++;

      if (strstr(line , word )!= NULL)
      {
          fprintf(fw, "<%s> <%d> %s",file3,i,line);

        }
   }
fclose(fw);




 int f_d = 1;



    char data[MAX_LINES][MAX_LEN];

  FILE *file;

   file = fopen("output.txt", "r");

  if (file == NULL)
  {
    printf("Error opening file.\n");
    return 1;
  }

  int line = 0;

   while (!feof(file) && !ferror(file))
    if (fgets(data[line], MAX_LEN, file) != NULL)
      line++;

  fclose(file);

  for (int i = 0; i < line; i++)
    printf("%s", data[i]);



    struct stat f_status;
    fstat(f_d, &f_status);
    off_t fstatus_size = f_status.st_size;

    fallocate(f_d, 0, fstatus_size, strlen(data));

    char *final_output = mmap(0, fstatus_size + strlen(data), PROT_WRITE, MAP_SHARED, f_d, 0);

    if (final_output == MAP_FAILED) {
        perror("Map Failed while mapping final output!");
    }

    for (int i = 0; i < strlen(data); ++i) {
        final_output[fstatus_size+i] = data[i];
    }

    if (munmap(final_output, strlen(final_output)) == -1) {
        perror("Error while removing mapping the file!");
    }

    close(f_d);

    return 0;

}

