#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <linux/mman.h>
#include <fcntl.h>
#include <unistd.h>

#include <wait.h>




int main(){




    struct stat f_status;
    fstat(file_d, &f_status);
    off_t fstatus_size = f_status.st_size;

    char *final_output = (char *) mmap(0, fstatus_size , PROT_READ, MAP_SHARED, file_d, 0);



    if (final_output == MAP_FAILED) {
        perror("Map Failed while mapping final output!");
    }


    FILE *output = fopen("output.txt" , "w");

    if (output == NULL) {
        perror("Error occurred when writing file!");
        exit(0);
    }
    fprintf(output, "%s", final_output);
    fclose(output);

    if (munmap(final_output, strlen(final_output)) == -1) {
        perror("Error while removing mapping the file!");
    }
    close(file_d);

return 0;

}
