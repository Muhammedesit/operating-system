#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>




int main(){


char word[20]="ali";
char file1[20]="input1.txt";
char file2[20]="input2.txt";
char file3[20]="input3.txt";





pid_t pid1,pid2,pid3;

   /* fork a child process */
  pid1 = fork();
  pid2 = fork();
  pid3 = fork();
  
FILE* fw = fopen("output.txt", "w+") ;
   

    if (pid1 == 0) { /* child process */
   	printf("I'm the child 1 \n");
char line[1024] ;
  FILE* fp1 = fopen(file1, "r") ;
    FILE* fw = fopen("output1.txt", "w+") ;
    int i=0;

   while (fgets(line , sizeof(line) , fp1 )!= NULL)
   {
   i++;

      if (strstr(line , word )!= NULL)
      {
          fprintf(fw, "<%s> <%d> %s",file1,i,line);

          }
   }


   }

   else { /* parent process */
   	  wait(NULL);

      char line[1024] ;
  FILE* fp1 = fopen("output1.txt", "r") ;
   
    

   while (fgets(line , sizeof(line) , fp1 )!= NULL)
   {
   

      
          fprintf(fw, " %s",line);

     
   }
fprintf(fw,"\n");
   	  printf("Child 1 Complete \n");
   }


/////////

   

    if (pid2 == 0) { /* child process */
   	printf("I'm the child 2 \n");
char line[1024] ;
FILE* fp2 = fopen(file2, "r") ;
    FILE* fw = fopen("output2.txt", "w+") ;
    int i=0;

   while (fgets(line , sizeof(line) , fp2 )!= NULL)
   {
   i++;

      if (strstr(line , word )!= NULL)
      {
          fprintf(fw, "<%s> <%d> %s",file2,i,line);

     }
   }

   }

   else { /* parent process */
   	  wait(NULL);

      char line[1024] ;
  FILE* fp1 = fopen("output2.txt", "r") ;
   
    

   while (fgets(line , sizeof(line) , fp1 )!= NULL)
   {
   

      
          fprintf(fw, " %s",line);

         
      
   }
fprintf(fw,"\n");
   	  printf("Child 2 Complete \n");
   }


////////


   

    if (pid3 == 0) { /* child process */
   	printf("I'm the child 3 \n"); 
char line[1024] ;
FILE* fp3 = fopen(file3, "r") ;
    FILE* fw = fopen("output3.txt", "w+") ;
    int i=0;

   while (fgets(line , sizeof(line) , fp3 )!= NULL)
   {
   i++;

      if (strstr(line , word )!= NULL)
      {
          fprintf(fw, "<%s> <%d> %s",file3,i,line);

       }
   }

   }

   else { /* parent process */
   	  wait(NULL);

      char line[1024] ;
  FILE* fp1 = fopen("output3.txt", "r") ;
   
    

   while (fgets(line , sizeof(line) , fp1 )!= NULL)
   {
   

      
          fprintf(fw, " %s",line);

         
      
   }
fprintf(fw,"\n");
   	  printf("Child 3 Complete \n");
   }





printf("\n");
 printf("end\n");
 printf("\n");


   return 0;
}