#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

void FindWord(char *word, char *file1, char *file2, char *file3)
{
    char line[1024];
    FILE *fp1 = fopen(file1, "r");
    FILE *fp2 = fopen(file2, "r");
    FILE *fp3 = fopen(file3, "r");
    FILE *fw = fopen("output.txt", "w+");
    int i = 0;

    while (fgets(line, sizeof(line), fp1) != NULL)
    {
        i++;

        if (strstr(line, word) != NULL)
        {
            fprintf(fw, "<%s> <%d> %s", file1, i, line);

            // printf("<%s> <%d> %s",file,i,line);
            // printf("line: %s",line);
        }
    }
    fprintf(fw, "\n");
    i = 0;

    while (fgets(line, sizeof(line), fp2) != NULL)
    {
        i++;

        if (strstr(line, word) != NULL)
        {
            fprintf(fw, "<%s> <%d> %s", file2, i, line);

            // printf("<%s> <%d> %s",file,i,line);
            // printf("line: %s",line);
        }
    }
    fprintf(fw, "\n");
    i = 0;

    while (fgets(line, sizeof(line), fp3) != NULL)
    {
        i++;

        if (strstr(line, word) != NULL)
        {
            fprintf(fw, "<%s> <%d> %s", file3, i, line);

            // printf("<%s> <%d> %s",file,i,line);
            // printf("line: %s",line);
        }
    }
}

int main()
{
    FILE *fw = fopen("output.txt", "w");

    printf("starting\n");

    char word[20] = "ali";
    char file1[20] = "input1.txt";
    char file2[20] = "input2.txt";
    char file3[20] = "input3.txt";

    // FindWord(word, file1, file2, file3);
    // FindWord(word, file1, NULL, NULL);

    int fd[2];
    pid_t childpid;

    int fd2[2];
    pid_t childpid2;

    int fd3[2];
    pid_t childpid3;

    pipe(fd3);

    pipe(fd2);

    pipe(fd);

    if ((childpid = fork()) == -1)
    {

        perror("fork");

        return 1;
    }

    if (childpid == 0)
    {
        /* Child process closes up input side of pipe */

        char line[1024];
        FILE *fp1 = fopen(file1, "r");
        FILE *fw = fopen("output1.txt", "w");
        int i = 0;

        while (fgets(line, sizeof(line), fp1) != NULL)
        {
            i++;

            if (strstr(line, word) != NULL)
            {
                fprintf(fw, "<%s> <%d> %s", file1, i, line);

                // printf("<%s> <%d> %s",file,i,line);
                // printf("line: %s",line);
            }
        }

        printf("1. if \n");
        fclose(fw);
        close(fd[0]);
    }
    else
    {
        printf("1. else \n");

        char line[1024];
        FILE *fp1 = fopen("output1.txt", "r");

        while (fgets(line, sizeof(line), fp1) != NULL)
        {

            fprintf(fw, " %s", line);

            // printf("<%s> <%d> %s",file,i,line);
            // printf("line: %s",line);
        }
        fprintf(fw, "\n");
        fclose(fw);
        /* Parent process closes up output side of pipe */
        close(fd[1]);
    }

    ///////////////////////////

    if ((childpid2 = fork()) == -1)
    {

        perror("fork");

        return 1;
    }

    if (childpid2 == 0)
    {
        /* Child process closes up input side of pipe */
        printf("2. if statement\n");

        char line[1024];
        FILE *fp2 = fopen(file2, "r");
        FILE *fw = fopen("output2.txt", "w");
        int i = 0;

        while (fgets(line, sizeof(line), fp2) != NULL)
        {
            i++;

            if (strstr(line, word) != NULL)
            {
                fprintf(fw, "<%s> <%d> %s", file2, i, line);

                // printf("<%s> <%d> %s",file,i,line);
                // printf("line: %s",line);
            }
        }
fclose(fw);
        close(fd2[0]);
    }
    else
    {
        printf("2. else \n");

        char line[1024];
        FILE *fp1 = fopen("output2.txt", "r");

        while (fgets(line, sizeof(line), fp1) != NULL)
        {

            fprintf(fw, " %s", line);

            // printf("<%s> <%d> %s",file,i,line);
            // printf("line: %s",line);
        }
        fprintf(fw, "\n");
        fclose(fw);
        /* Parent process closes up output side of pipe */
        close(fd2[1]);
    }

    ///////////////////

    if ((childpid3 = fork()) == -1)
    {
        perror("fork");

        return 1;
    }

    if (childpid3 == 0)
    {
        /* Child process closes up input side of pipe */
        printf("3. if statement\n");

        char line[1024];
        FILE *fp3 = fopen(file3, "r");
        FILE *fw = fopen("output3.txt", "w");
        int i = 0;

        while (fgets(line, sizeof(line), fp3) != NULL)
        {
            i++;

            if (strstr(line, word) != NULL)
            {
                fprintf(fw, "<%s> <%d> %s", file3, i, line);

                // printf("<%s> <%d> %s",file,i,line);
                // printf("line: %s",line);
            }
        }
fclose(fw);
        close(fd3[0]);
    }
    else
    {
        printf("3. else\n");

        char line[1024];
        FILE *fp1 = fopen("output3.txt", "r");

        while (fgets(line, sizeof(line), fp1) != NULL)
        {

            fprintf(fw, " %s", line);

            // printf("<%s> <%d> %s",file,i,line);
            // printf("line: %s",line);
        }
        fprintf(fw, "\n");
        fclose(fw);
        /* Parent process closes up output side of pipe */
        close(fd3[1]);
        return 0;
    }

    //////////////////////////////////////////////////////////////////////////////////

    printf("\n");
    printf("ending\n");
    printf("\n");
    printf("\n");

    return 0;
}