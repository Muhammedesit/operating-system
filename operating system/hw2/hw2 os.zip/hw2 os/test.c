#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Mutex and condition variables for each philosopher
pthread_mutex_t forks[27];
pthread_cond_t cvs[27];

// Philosopher struct
typedef struct {
    int id;
    int num_philosophers;
    int num_dines;
    int min_think;
    int max_think;
    int min_dine;
    int max_dine;
} philosopher_t;

// Thread function for each philosopher
void* philosopher_thread(void* arg) {
    philosopher_t* p = (philosopher_t*) arg;
    int i;
    for (i = 0; i < p->num_dines; i++) {
        // Think
        int think_time = (p->min_think + rand() % (p->max_think - p->min_think)) * 1000;
        printf("Philosopher %d is thinking for %d milliseconds\n", p->id, think_time);
        usleep(think_time);

        // Pick up left fork
        pthread_mutex_lock(&forks[p->id]);
        printf("Philosopher %d picked up fork %d\n", p->id, p->id);

        // Wait for right fork
        pthread_mutex_lock(&forks[(p->id + 1) % p->num_philosophers]);
        printf("Philosopher %d picked up fork %d\n", p->id, (p->id + 1) % p->num_philosophers);

        // Dine
        int dine_time = (p->min_dine + rand() % (p->max_dine - p->min_dine)) * 1000;
        printf("Philosopher %d is eating for %d milliseconds\n", p->id, dine_time);
        usleep(dine_time);

        // Put down forks
        pthread_mutex_unlock(&forks[p->id]);
        pthread_mutex_unlock(&forks[(p->id + 1) % p->num_philosophers]);
    }
    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    if (argc != 7) {
        printf("Usage: %s <num_philosophers> <num_dines> <min_think> <max_think> <min_dine> <max_dine>\n", argv[0]);
        return 1;
    }
    int num_philosophers = atoi(argv[1]);
    int num_dines = atoi(argv[2]);
    int min_think = atoi(argv[3]);
    int max_think = atoi(argv[4]);
    int min_dine = atoi(argv[5]);
    int max_dine = atoi(argv[6]);

        // Initialize mutexes and condition variables
    int i;
    for (i = 0; i < num_philosophers; i++) {
        pthread_mutex_init(&forks[i], NULL);
    }

    // Create philosopher threads
    pthread_t philosophers[num_philosophers];
    philosopher_t philosophers_data[num_philosophers];
    for (i = 0; i < num_philosophers; i++) {
        philosophers_data[i].id = i;
        philosophers_data[i].num_philosophers = num_philosophers;
        philosophers_data[i].num_dines = num_dines;
        philosophers_data[i].min_think = min_think;
        philosophers_data[i].max_think = max_think;
        philosophers_data[i].min_dine = min_dine;
        philosophers_data[i].max_dine = max_dine;
        pthread_create(&philosophers[i], NULL, philosopher_thread, &philosophers_data[i]);
    }

    // Wait for philosopher threads to complete
    for (i = 0; i < num_philosophers; i++) {
        pthread_join(philosophers[i], NULL);
    }

    // Clean up mutexes and condition variables
    for (i = 0; i < num_philosophers; i++) {
        pthread_mutex_destroy(&forks[i]);
    }

    return 0;
}